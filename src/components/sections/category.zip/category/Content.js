import React, { Component, Fragment } from 'react';
import { Link } from 'react-router-dom';
import Cars from "../home/Cars";
import Media from "../home/Blogs";
import FAQ from "../home/faq";
import Details from "./Details";
import $ from "jquery";
import * as CONSTANT from '../../../Constent';
//import MultiRangeSlider from "./rangeslider";
import Nouislider from "nouislider-react";
import "nouislider/distribute/nouislider.css";

class Content extends Component {
    constructor() {
        super();
        this.state = {
            car_listing: [],
            total_cars: '',
            limit: 9,

            makemodel: [],
            fueltype: [],
            year: [],

            changepara: 0,
            formvalue: "",
            isloading: true,

            makebradcrumb: "",
            modelbradcrumb: "",

            makebradcrumb_id: "",
            modelbradcrumb_id: "",

            fuel: [],
            fyear: "",
            kmdriven: "",
            owner: "",
            price: "",
            carminprice: 50000,
            carmaxprice: 4000000
        }
        this.handleScroll = this.handleScroll.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.makeChange = this.makeChange.bind(this);
        this.modelChange = this.modelChange.bind(this);
        this.openModel = this.openModel.bind(this);
        this.filterClick = this.filterClick.bind(this);


        window.addEventListener('scroll',this.handleScroll,true);
       
    }
    onSlide = (render, handle, value, un, percent) => {

        console.log(value);

        this.setState({
            carminprice: Math.round(value[0]),
            carmaxprice: Math.round(value[1])
        });

        var minprice = new Intl.NumberFormat('US').format(this.state.carminprice).split(",");
        var maxprice = new Intl.NumberFormat('US').format(this.state.carmaxprice).split(",");
        if (minprice[1] > 0) {
            var min = minprice[0] + "." + minprice[1];
        }
        else {
            var min = minprice[0];
        }


        if (maxprice[1] != "00") {
            var max = maxprice[0] + "." + maxprice[1];
        }
        else {
            var max = maxprice[0];
        }




        console.log(minprice);
        console.log(maxprice);

        this.setState({ price: "Rs " + min + "-" + max + " L" + " X" });
        $(".p_hwe").css({ "padding": "7px", "margin-top": "5px", "margin-left": "5px" })
        $(".p_hwe").attr("data-id", this.state.carminprice);
        $(".p_hwe").attr("data-id1", this.state.carmaxprice);
        $('.filter_save').trigger('click');
        $(".clear_all").show();


    };
    componentDidMount() {

        $(".navigation-wrapper").hide();
        this.car_listing();

        // setTimeout(() => {
        //     $(".clear_all").show();
        // }, 5000);

        const search = window.location.search;
        const make_ids = new URLSearchParams(search).get('make_ids[]');
        const modal_ids = new URLSearchParams(search).get('modal_ids[]');
        const fuel_type = new URLSearchParams(search).get('fuel_type[]');
        const car_year = new URLSearchParams(search).get('car_year');
        const km_driven = new URLSearchParams(search).get('km_driven');
        const owner = new URLSearchParams(search).get('owner');
        const car_min_price = new URLSearchParams(search).get('car_min_price');
        const car_max_price = new URLSearchParams(search).get('car_max_price');

        if (make_ids) {
            setTimeout(() => {
                $(".make_ids" + make_ids).prop("checked", true);
                if ($(".make_ids" + make_ids).prop("checked") == true) {
                    $(".hwe" + make_ids).prop('checked', true);
                    var modelcheck = $('input.modelcheckval:checked').length;
                    if (modelcheck == 1) {
                        var modelcheck = $('.modelcheckval:checked').next("p").html();
                        this.setState({ modelbradcrumb: "> " + modelcheck });
                        var modelcheck_val = $('.modelcheckval:checked').val();
                        this.setState({ modelbradcrumb_id: modelcheck_val });
                    }
                }
                var makechecked = $('input.makecheckval:checked').next("p").html();
                this.setState({ makebradcrumb: "> " + makechecked });
                this.setState({ makebradcrumb_id: make_ids });
            }, 5000);
        }
        else if (modal_ids) {
            setTimeout(() => {
                $(".modal_ids" + modal_ids).prop("checked", true);
                var modelcheck = $('input.modelcheckval:checked').length;
                if (modelcheck == 1) {
                    var modelcheck = $('.modelcheckval:checked').next("p").html();
                    this.setState({ modelbradcrumb: "> " + modelcheck });

                    this.setState({ modelbradcrumb_id: modal_ids });
                }
            }, 5000);
        }
        else if (fuel_type) {
            $(".clear_all").show();
            setTimeout(() => {
                $(".fuel_type" + fuel_type).prop("checked", true);
                var fuelval = [];
                var i = 0;
                $(".fueltype:checkbox:checked").each(function () {
                    var fuilval = $(this).val();
                    var fuilattr = $(this).attr('fuil_type');
                    fuelval[i++] = { 'id': fuilval, name: fuilattr };
                });
                this.setState({ fuel: fuelval })
            }, 5000);
        }
        else if (car_year) {
            $(".clear_all").show();
            setTimeout(() => {
                $(".car_year" + car_year).prop("checked", true);
                this.setState({ fyear: car_year + " & above X" });
                $(".y_hwe").css({ "padding": "7px", "margin-top": "5px", "margin-left": "5px" })
                let y_hwe = $(".car_year" + car_year).val();
                $(".y_hwe").attr("data-id", y_hwe);
                $(".clear_all").show();
            }, 5000);
        }
        else if (km_driven) {
            $(".clear_all").show();
            setTimeout(() => {
                $(".km_driven" + km_driven).prop("checked", true);
                this.setState({ kmdriven: new Intl.NumberFormat('US').format(km_driven) + " km X" });
                $(".km_hwe").css({ "padding": "7px", "margin-top": "10px", "margin-left": "5px" })
                let km_hwe = $(".km_driven" + km_driven).val();
                $(".km_hwe").attr("data-id", km_hwe);
                $(".clear_all").show();
            }, 5000);
        }
        else if (owner) {
            $(".clear_all").show();
            setTimeout(() => {
                $(".owner" + owner).prop("checked", true);
                var ownerattr = $(".owner" + owner).attr('owner');
                this.setState({ owner: ownerattr + " X" });
                $(".o_hwe").css({ "padding": "7px", "margin-top": "5px", "margin-left": "5px" })
                let o_hwe = $(".owner" + owner).val();
                $(".o_hwe").attr("data-id", o_hwe);
                $(".clear_all").show();
            }, 5000);
        }
        else if (car_min_price && car_max_price) {
            $(".clear_all").show();
            this.setState({ carminprice: car_min_price });
            this.setState({ carmaxprice: car_max_price });
            var minprice = new Intl.NumberFormat('US').format(car_min_price).split(",");
            var maxprice = new Intl.NumberFormat('US').format(car_max_price).split(",");
            if (maxprice[1] != "00") {
                var max = maxprice[0] + "." + maxprice[1];
            }
            else {
                var max = maxprice[0];
            }
            if (minprice[1] != "00") {
                var min = minprice[0] + "." + minprice[1];
            }
            else {
                var min = minprice[0];
            }



            this.setState({ price: "Rs " + min + "-" + max + " L" + " X" });
            $(".p_hwe").css({ "padding": "7px", "margin-top": "5px", "margin-left": "5px" })
            $(".p_hwe").attr("data-id", car_min_price);
            $(".p_hwe").attr("data-id1", car_max_price);
            $(".clear_all").show();
        }

        ///////////////////Get Make & Model////////////////////
        fetch(`${CONSTANT.BaseUrl}/services/get_modal_bymakeid`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ makemodel: response.result })
            })
            .catch((error) => {
            });

        ///////////////////Get Fueltype////////////////////
        fetch(`${CONSTANT.BaseUrl}/services/getfueltype`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ fueltype: response.result })
            })
            .catch((error) => {
            });

        ///////////////////Get Year////////////////////
        fetch(`${CONSTANT.BaseUrl}/services/getyear`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ year: response.result })
            })
            .catch((error) => {
            });
    }

    ///////////////////Get Car listing////////////////////
    car_listing() {
        var city = localStorage.getItem("selected_city");
        if (city == null) {
            alert("Please Select City");
            window.location.href = "/"
        }

        $(".loader").show();

        var filter = "";
        if (this.state.changepara == 0) {
            const queryString = window.location.search;
            var filter = queryString.replace("?", "");
        }
        else if (this.state.changepara == 1) {
            var filter = this.state.formvalue;
        }

        const d = new Date();
        let time = d.getTime();

        fetch(`${CONSTANT.BaseUrl}/services/get_car_listing?limit=${this.state.limit}&start=0&${filter}&time=${time}`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ car_listing: response.result })
                this.setState({ total_cars: response.total_cars })
                this.setState({ isloading: true })
                $(".loader").hide();
            })
            .catch((error) => {
            });
    }

    handleScroll = (event) => {
        

        var scrollHeight = $(document).height() - $(".hwefeature").height() - $(".footer").height();
        // alert(scrollHeight);
        var scrollPos = $(window).height() + $(window).scrollTop();
        if (((scrollHeight - 500) >= scrollPos) / scrollHeight == 0)
        {
        this.car_listing();
        $(".loader").show();
        if (this.state.isloading == true) {
            this.setState({ limit: this.state.limit + 9 })
        }
        this.setState({ isloading: false })
       }
    }

    handleSubmit(e) {
        e.preventDefault();

        var formvalue = $("form :input[value!='']").serialize();
        this.setState({ formvalue: this.state.formvalue = formvalue })

        this.setState({ limit: this.state.limit = 9 })

        this.setState({ changepara: this.state.changepara = 1 })

        this.car_listing();
    }

    handleChange(e) {
        $('.filter_save').trigger('click');

        var fuellength = $(".fueltype:checkbox:checked").length;
        if (fuellength > 0) {
            $(".clear_all").show();
            var fuelval = [];
            var i = 0;
            $(".fueltype:checkbox:checked").each(function () {
                var fuilval = $(this).val();
                var fuilattr = $(this).attr('fuil_type');
                fuelval[fuilval] = { 'id': fuilval, name: fuilattr };
            });

            this.setState({ fuel: fuelval })
        }
        var year = $('input[name=car_year]:checked').val();
        if (year != undefined) {
            $(".clear_all").show();
            this.setState({ fyear: year + " & above X" });
            $(".y_hwe").css("padding", "7px");
            $(".y_hwe").attr("data-id", year);
            $(".clear_all").show();
        }

        var kmdriven = $('input[name=km_driven]:checked').val();
        if (kmdriven != undefined) {
            $(".clear_all").show();
            this.setState({ kmdriven: new Intl.NumberFormat('US').format(kmdriven) + " km X" });
            $(".km_hwe").css("padding", "7px");
            $(".km_hwe").attr("data-id", kmdriven);
            $(".clear_all").show();
        }

        var owner = $('input[name=owner]:checked').attr('owner');
        if (owner != undefined) {
            $(".clear_all").show();
            this.setState({ owner: owner + " X" });
            $(".o_hwe").css("padding", "7px");

            var ownerval = $('input[name=owner]:checked').val();
            $(".o_hwe").attr("data-id", ownerval)
            $(".clear_all").show();
        }
    }

    filterClick(e, id) {
        var attrval = e.currentTarget.getAttribute('data-id');
        // var attrval1 = e.currentTarget.getAttribute('data-id1');

        if (id == 1) {
            const fuelhwe = this.state.fuel;

            delete fuelhwe[attrval];

            $('.fuel_type' + attrval).prop('checked', false);

            var fuelval = [];
            $(".fueltype:checkbox:checked").each(function () {
                var fuilval = $(this).val();
                var fuilattr = $(this).attr('fuil_type');
                fuelval[fuilval] = { 'id': fuilval, name: fuilattr };
            });

            this.setState({ fuel: fuelval })

        } else if (id == 2) {

            $('.car_year' + attrval).prop('checked', false);
            this.setState({ fyear: "" });
            $(".y_hwe").css("padding", "0");

        } else if (id == 3) {

            $('.km_driven' + attrval).prop('checked', false);
            this.setState({ kmdriven: "" });
            $(".km_hwe").css("padding", "0");

        } else if (id == 4) {

            $('.owner' + attrval).prop('checked', false);
            this.setState({ owner: "" });
            $(".o_hwe").css("padding", "0");

        } else if (id == 5) {

            this.setState({ price: "" });
            $(".p_hwe").css("padding", "0");

        }
        else if (id == "all") {

            const fuelhwe = this.state.fuel;
            fuelhwe.length = 0;
            $('.fueltype').prop('checked', false);
            $(".f_hwe").css("padding", "0");

            $('.car_year').prop('checked', false);
            this.setState({ fyear: "" });
            $(".y_hwe").css("padding", "0");

            $('.kmdriven').prop('checked', false);
            this.setState({ kmdriven: "" });
            $(".km_hwe").css("padding", "0");

            $('.owner').prop('checked', false);
            this.setState({ owner: "" });
            $(".o_hwe").css("padding", "0");

            this.setState({ price: "" });
            $(".p_hwe").css("padding", "0");

            $('.clear_all').hide();

        }

        // if(this.state.fuel && this.state.fyear && this.state.kmdriven && this.state.owner && this.state.price == ""){
        //     $('.clear_all').hide();
        // }

        $('.filter_save').trigger('click');
    }

    handleClick(e) {
        $('.filter_save').trigger('click');
    }

    openModel(id) {
        $(".model" + id).toggle();
    }

    makeChange(make) {
        var makecheckval = $('input.makecheckval:checked').length;
        var modelcheckval = $('input.modelcheckval:checked').length;
        var modelcheckval1 = $('input.modelcheckval:checked').attr('data-id');

        if (makecheckval == 0 && modelcheckval == 0) {
            this.setState({ makebradcrumb: "" })
            this.setState({ modelbradcrumb: "" })
        }
        if (makecheckval == 1 && modelcheckval == 0) {
            var makebradcrumb = $('input.makecheckval:checked').next().html();
            this.setState({ makebradcrumb: "> " + makebradcrumb })
        }
        else if (makecheckval == 1 && modelcheckval == 1) {
            var singlemakeval = $('input.makecheckval:checked').val();
            if (make == modelcheckval1) {
                var makebradcrumb = $('input.makecheckval:checked').next().html();
                this.setState({ makebradcrumb: "> " + makebradcrumb })
                var modelbradcrumb = $('input.modelcheckval:checked').next().html();
                this.setState({ modelbradcrumb: "> " + modelbradcrumb })
            }
            else if (singlemakeval == modelcheckval1) {
                var makebradcrumb = $('input.makecheckval:checked').next().html();
                this.setState({ makebradcrumb: "> " + makebradcrumb })
                var modelbradcrumb = $('input.modelcheckval:checked').next().html();
                this.setState({ modelbradcrumb: "> " + modelbradcrumb })
            }
        }
        else if (makecheckval < 1) {
            this.setState({ makebradcrumb: "" })
        }
        else if (makecheckval > 1) {
            this.setState({ makebradcrumb: "" })
        }
        if (modelcheckval > 1) {
            this.setState({ makebradcrumb: "" })
            this.setState({ modelbradcrumb: "" })
        }
        else if (makecheckval > 1 && modelcheckval > 0) {
            this.setState({ makebradcrumb: "" })
            this.setState({ modelbradcrumb: "" })
        }
        else if (makecheckval == 1 && modelcheckval > 1) {
            this.setState({ makebradcrumb: "" })
            this.setState({ modelbradcrumb: "" })
        }
        else if (makecheckval == 1 && modelcheckval == 1 && $(".make_ids" + make).is(':checked')) {
            var makebradcrumb = $('input.makecheckval:checked').next().html();
            this.setState({ makebradcrumb: "> " + makebradcrumb })
            var modelbradcrumb = $('input.modelcheckval:checked').next().html();
            this.setState({ modelbradcrumb: "> " + modelbradcrumb })
        }
        else if (modelcheckval < 1 || modelcheckval > 1) {
            this.setState({ modelbradcrumb: "" })
        }
    }

    modelChange(make) {
        var makecheckval = $('input.makecheckval:checked').length;
        var modelcheckval = $('input.modelcheckval:checked').length;
        var modelcheckval1 = $('input.modelcheckval:checked').attr('data-id');

        if (makecheckval == 0 && modelcheckval == 1) {
            var modelbradcrumb = $('input.modelcheckval:checked').next().html();
            this.setState({ modelbradcrumb: "> " + modelbradcrumb })
        }
        else if (makecheckval == 1 && modelcheckval == 1) {
            var singlemakeval = $('input.makecheckval:checked').val();
            if (make == modelcheckval1) {
                var makebradcrumb = $('input.makecheckval:checked').next().html();
                this.setState({ makebradcrumb: "> " + makebradcrumb })
                var modelbradcrumb = $('input.modelcheckval:checked').next().html();
                this.setState({ modelbradcrumb: "> " + modelbradcrumb })
            }
            else if (singlemakeval == modelcheckval1) {
                var makebradcrumb = $('input.makecheckval:checked').next().html();
                this.setState({ makebradcrumb: "> " + makebradcrumb })
                var modelbradcrumb = $('input.modelcheckval:checked').next().html();
                this.setState({ modelbradcrumb: "> " + modelbradcrumb })
            }
            else {
                this.setState({ makebradcrumb: "" })
                this.setState({ modelbradcrumb: "" })
            }
        }
        else if (makecheckval == 1 && modelcheckval == 0) {
            var makebradcrumb = $('input.makecheckval:checked').next().html();
            this.setState({ makebradcrumb: "> " + makebradcrumb })
            this.setState({ modelbradcrumb: "" })
        }
        else if (modelcheckval < 1 || modelcheckval > 1) {
            this.setState({ modelbradcrumb: "" })
        }
        else if (makecheckval > 1 && modelcheckval > 0) {
            this.setState({ makebradcrumb: "" })
            this.setState({ modelbradcrumb: "" })
        }
        else if (makecheckval == 1 && modelcheckval == 1 && !$(".make_ids" + make).is(':checked')) {
            this.setState({ makebradcrumb: "" })
            this.setState({ modelbradcrumb: "" })
        }
    }

    render() {


       

        const { carminprice, carmaxprice } = this.state;
        var city_name = localStorage.getItem("selected_city");
        if (city_name) {
            var selected_city = localStorage.getItem("selected_city");
        } else {
            var selected_city = "India";
        }
        const pagelocation = "Used cars in " + selected_city;

        $(document).ready(function () {
            $(".makecheckval").click(function () {
                if ($(this).prop("checked") == true) {
                    var makeval = $(this).val();
                    $(".hwe" + makeval).prop('checked', true);
                } else if ($(this).prop("checked") == false) {
                    var makeval = $(this).val();
                    $(".hwe" + makeval).prop('checked', false);
                }
            });
        });

        $(document).ready(function () {

            $(".sort_category").click(function () {
                $(".shorting_menu").show();
            });
            $(".sort_category").dblclick(function () {
                $(".shorting_menu").hide();
            });

            $(".dropvalue").click(function () {
                var newval = $(this).val();
                var newtext = $(this).html();
                $(".sort_category").html('<i class="fa fa-sort">' + '&nbsp;&nbsp;' + newtext + '&nbsp;&nbsp;&nbsp;');
                $(".dropdown-menu").hide();
                $(".car_sorting").val(newval);
            });

        });

        const paginationData = this.state.car_listing.map((Car) => {
            return <div className="col-md-4" id="paginationData">
                <div className="car-grid mb-xl-30 category" style={{ boxShadow: "0 0 10px #dbdbdb" }}>
                    <div className="car-grid-wrapper car-grid bx-wrapper rounded">
                        <Link to={"/car-details?car_id=" + Car.index + "&make_id=" + Car.make_id + "&modal_id=" + Car.modal_id}>
                            <div className="image-sec animate-img">
                                <img src={Car.images} className="full-width" />
                            </div>
                        </Link>
                        <div className="car-grid-caption padding-10 bg-custom-white p-relative">
                            <h4 className="col-md-12 title fs-16 pl-1 pr-1 mb-2">
                                <Link to={"/car-details?car_id=" + Car.index + "&make_id=" + Car.make_id + "&modal_id=" + Car.modal_id}><span>{Car.name}</span><small className="mt-2 mb-2" style={{ fontSize: "13px", fontWeight: "500" }}>{new Intl.NumberFormat('US').format(Car.kmdriven)} KM . {Car.fuil_type} . {Car.year}</small><h5>Rs.{new Intl.NumberFormat('US').format(Car.price)}</h5></Link>
                            </h4>
                            <div style={{ borderTop: "1px solid #dbdbdb", padding: "0.5rem" }}>
                                <a href={Car.carurl} target="_blank" ><span className="car_footer mb-0 fw-1000" style={{ color: "#6300a3" }}>Check this on CarWale</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        });

        return (

            <Fragment>

                <section className="section-padding bg-light-white pb-4" style={{ paddingTop: "10px" }}>
                    <div className="container-fluid fluidhwe" style={{ padding: "0rem 3rem" }}>
                        <div className="row">
                            <h6 className="d-none">1</h6>
                            <aside className="col-lg-3">
                                <div className="sidebar_wrap mb-md-80">
                                    <div className="sidebar" style={{ maxHeight: "1100px", overflowY: "scroll", scrollbarWidth: "thin" }}>
                                        <div className="sidebar_widgets sidebar">
                                            <form method="GET" action="" onChange={this.handleChange} onSubmit={this.handleSubmit}>

                                                <input type="hidden" name="car_sorting" Value="" className="car_sorting" />
                                                <div className="row" style={{ display: "none" }}>
                                                    <div className="col-md-12">
                                                        <button type="submit" className="btn-first btn-small btn-block filter_save">Filter</button>
                                                    </div>
                                                </div>

                                                <div className="widget_title">


                                                    <h6 className="no-margin text-custom-white" style={{ color: "#2e054e", fontFamily: "futura Lt BT" }}>Budget</h6>
                                                </div>
                                                <div className="widget_title mt-2 pt-2" style={{ border: "none" }}>
                                                    <div>
                                                        <Nouislider
                                                            connect
                                                            start={[this.state.carminprice, this.state.carmaxprice]}
                                                            behaviour="tap"
                                                            range={{
                                                                'min': [50000, 50000],
                                                                '47%': [400000, 100000],
                                                                '67%': [800000, 200000],
                                                                '72%': [1000000, 500000],
                                                                '75%': [1500000, 1500000],
                                                                'max': [4000000]
                                                            }}
                                                            onSlide={this.onSlide}
                                                        />
                                                        {carminprice && carmaxprice && (
                                                            <div>
                                                                {new Intl.NumberFormat('US').format(carminprice)} - {new Intl.NumberFormat('US').format(carmaxprice)}
                                                            </div>
                                                        )}
                                                    </div>

                                                    <input type="hidden" name="car_min_price" value={carminprice} />
                                                    <input type="hidden" name="car_max_price" value={carmaxprice} />
                                                    {/* 
                                                    <MultiRangeSlider
                                                        className="budget"
                                                        min={50000}
                                                        max={4000000}
                                                        onChange={({ min, max }) => console.log(`min = ${min}, max = ${max}`)}
                                                    />  */}
                                                </div>

                                                <div className="widget_title mt-2 pt-2">
                                                    <h6 className="no-margin text-custom-white" style={{ color: "#2e054e", fontFamily: "futura Lt BT" }}>Make + Model</h6>
                                                </div>
                                                <input type="search" className="form-control filter" placeholder="Search by Make or Model..." style={{ opacity: "70% !important" }} />
                                                <div className="checkbox-group" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "thin" }}>
                                                    {this.state.makemodel.map((makemodel) => (
                                                        <div className="form-group" style={{ borderBottom: "1px solid #f0eded" }}>
                                                            <div className="row make">
                                                                <div className="col-sm-9 pl-0 phead">
                                                                    <label className="custom-checkbox makecheck">
                                                                        <input type="checkbox" onChange={() => this.makeChange(makemodel.make.index)} className={`makecheckval make_ids${makemodel.make.index}`} value={makemodel.make.index} />
                                                                        <p style={{ display: "none" }}>{makemodel.make.name}</p>
                                                                        <span className="checkmark" /> {makemodel.make.name}
                                                                    </label>
                                                                </div>
                                                                <div className="col-sm-3 text-right" style={{ cursor: "pointer" }} onClick={() => this.openModel(makemodel.make.index)}><i className="fa fa-angle-down makedownhwe"></i></div>
                                                                <div className={`model model${makemodel.make.index}`} style={{ display: "none" }}>
                                                                    {makemodel.modal.map(modal => (
                                                                        <label className="custom-checkbox mt-3 ml-1 modelcheck">
                                                                            <input type="checkbox" onChange={() => this.modelChange(makemodel.make.index, modal.index)} className={`modelcheckval hwe${makemodel.make.index} modal_ids${modal.index}`} data-id={makemodel.make.index} name='modal_ids[]' Value={modal.index} />
                                                                            <p style={{ display: "none" }}>{modal.name}</p>
                                                                            <span className="checkmark" /> {modal.name}
                                                                        </label>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>

                                                <div className="widget_title mt-4">
                                                    <h6 className="no-margin text-custom-white" style={{ color: "#2e054e", fontFamily: "futura Lt BT" }}>Fuel Type</h6>
                                                </div>
                                                {/* <div className="checkbox-group sidebar" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "thin" }}> */}
                                                <div className="checkbox-group sidebar" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none" }}>
                                                    {this.state.fueltype.map(fueltype =>
                                                        <div className="form-group">
                                                            <label className="custom-checkbox">
                                                                <input type="checkbox" className={`fueltype fuel_type${fueltype.index}`} name="fuel_type[]" fuil_type={fueltype.name} Value={fueltype.index} />
                                                                <span className="checkmark" />{fueltype.name}</label>
                                                        </div>
                                                    )}
                                                </div>

                                                <div className="widget_title mt-4">
                                                    <h6 className="no-margin text-custom-white" style={{ color: "#2e054e", fontFamily: "futura Lt BT" }}>Year</h6>
                                                </div>
                                                <div className="checkbox-group sidebar" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "thin" }}>
                                                    {this.state.year.map(year =>
                                                        <div className="form-group">
                                                            <label className="custom-radio">
                                                                <input type="radio" className={`car_year car_year${year.name}`} name="car_year" Value={year.name} style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                                <span className="checkmark" /> {year.name} & above </label>
                                                        </div>
                                                    )}
                                                </div>

                                                <div className="widget_title mt-4">
                                                    <h6 className="no-margin text-custom-white" style={{ color: "#2e054e", fontFamily: "futura Lt BT" }}>KM Driven</h6>
                                                </div>
                                                {/* <div className="checkbox-group sidebar" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "thin" }}> */}
                                                <div className="checkbox-group sidebar" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none" }}>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="kmdriven km_driven10000" name="km_driven" Value="10000" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> {new Intl.NumberFormat('US').format(10000)} kms & less
                                                        </label>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="kmdriven km_driven30000" name="km_driven" Value="30000" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> {new Intl.NumberFormat('US').format(30000)} kms & less
                                                        </label>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="kmdriven km_driven50000" name="km_driven" Value="50000" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> {new Intl.NumberFormat('US').format(50000)} kms & less
                                                        </label>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="kmdriven km_driven75000" name="km_driven" Value="75000" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> {new Intl.NumberFormat('US').format(75000)} kms & less
                                                        </label>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="kmdriven km_driven100000" name="km_driven" Value="100000" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> {new Intl.NumberFormat('US').format(100000)} kms & less
                                                        </label>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="kmdriven km_driven200000" name="km_driven" Value="200000" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> {new Intl.NumberFormat('US').format(200000)} kms & less
                                                        </label>
                                                    </div>
                                                </div>

                                                <div className="widget_title mt-4">
                                                    <h6 className="no-margin text-custom-white" style={{ color: "#2e054e", fontFamily: "futura Lt BT" }}>Owner</h6>
                                                </div>
                                                {/* <div className="checkbox-group sidebar" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "thin" }}> */}
                                                <div className="checkbox-group sidebar" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none" }}>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="owner owner1" name="owner" owner="1st owner" Value="1" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> 1-owner
                                                        </label>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="owner owner2" name="owner" owner="2nd owner" Value="2" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> 2-owner
                                                        </label>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="owner owner3" name="owner" owner="3rd owner" Value="3" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> 3-owner
                                                        </label>
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="custom-radio">
                                                            <input type="radio" className="owner owner4" name="owner" owner="4th & more owner" Value="4" style={{ height: "20px", width: "20px", position: "relative", top: "2px" }} />
                                                            <span className="checkmark" /> 4 or more-owner
                                                        </label>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </aside>
                            <div className="col-lg-9">
                                <div className="cat_list list_listitem" onScroll={this.handleScroll}>
                                    <div className="row">
                                        <div className="row">
                                            <div className="col-md-12">
                                                <span> <Link to="/" style={{ textTransform: "uppercase", color: "#411c5f", fontWeight: "500", fontFamily: "Futura Md BT", fontSize: "12px", letterSpacing: "1px" }}>Home <i className="fa fa-angle-right"></i></Link> </span>
                                                <span className="fw-500 citybradcrumb" aria-current="page"><a href={`/category?city_id=${localStorage.getItem("city_id")}`} style={{ textTransform: "uppercase", color: "#a593b3", fontWeight: "500", fontFamily: "Futura Md BT", fontSize: "12px" }}>{pagelocation}</a>&nbsp;</span>
                                                <span className="fw-500 make_bradcrumb"><a href={`/category?city_id=${localStorage.getItem("city_id")}&make_ids[]=${this.state.makebradcrumb_id}`} style={{ textTransform: "uppercase", color: "#a593b3", fontWeight: "500", fontFamily: "Futura Md BT", fontSize: "12px" }}>{" " + this.state.makebradcrumb}</a></span>
                                                <span className="fw-500 make_bradcrumb"><a href={`/category?city_id=${localStorage.getItem("city_id")}&modal_ids[]=${this.state.modelbradcrumb_id}`} style={{ textTransform: "uppercase", color: "#a593b3", fontWeight: "500", fontFamily: "Futura Md BT", fontSize: "12px" }}>{" " + this.state.modelbradcrumb}</a></span>
                                            </div>
                                        </div>
                                        <div className="row mt-3 pb-3 pr-0 filter_short_hwe">

                                            <div className="col-md-6 pt-1 pb-2 filteradd_hwe filteradd_hwe_parent" style={{ display: "flex", flexWrap: "wrap" }}>
                                                <button className="top_filterhwe clear_all" onClick={(e) => this.filterClick(e, "all")} style={{ display: "none" }}> <i class="fa fa-refresh"></i> Clear All</button> &nbsp;
                                                <span className="top_filterhwe linetext p_hwe" onClick={(e) => this.filterClick(e, 5)} data-id="" data-id1="">{this.state.price}</span> &nbsp;
                                                <span className="top_filterhwe linetext km_hwe" onClick={(e) => this.filterClick(e, 3)} data-id="">{this.state.kmdriven}</span> &nbsp;
                                                <span className="top_filterhwe linetext o_hwe" onClick={(e) => this.filterClick(e, 4)} data-id="">{this.state.owner}</span> &nbsp;
                                                <span className="top_filterhwe linetext y_hwe" onClick={(e) => this.filterClick(e, 2)} data-id="">{this.state.fyear}</span> &nbsp;
                                                {this.state.fuel.map(fuel =>
                                                    <span className={`top_filterhwe f_hwe f_hwe${fuel.id}`} onClick={(e) => this.filterClick(e, 1)} data-id={fuel.id} style={{ padding: "7px 12px", marginLeft: "5px", marginRight: "5px" }}>{fuel.name + " X"}</span>
                                                )}
                                            </div>


                                            <div className="col-md-6 text-right pr-0" style={{ width: "60% !important" }}>
                                                <div class="btn-group custome_group">
                                                    <button type="button" className="btn btn-block sort_category"><i className="fa fa-sort"></i>&nbsp; Newest First &nbsp;&nbsp;&nbsp;</button>
                                                    <ul className="dropdown-menu shorting_menu">
                                                        <li className="dropvalue" value="1" onClick={this.handleClick}>Newest First</li>
                                                        <li className="dropvalue" value="2" onClick={this.handleClick}>Price - Low to High</li>
                                                        <li className="dropvalue" value="3" onClick={this.handleClick}>Price - High to Low</li>
                                                        <li className="dropvalue" value="4" onClick={this.handleClick}>KM Driven - Low to High</li>
                                                        <li className="dropvalue" value="5" onClick={this.handleClick}>KM Driven - High to Low</li>
                                                        <li className="dropvalue" value="6" onClick={this.handleClick}>Year - Old to New</li>
                                                        <li className="dropvalue" value="7" onClick={this.handleClick}>Year - New to Old</li>
                                                    </ul>
                                                </div>
                                            </div>

                                            <div className="col-md-6 pt-2">
                                                <span className="no-margin text-custom-black mt-2 mb-3" style={{ color: "#2e054e", fontWeight: "400", fontSize: "15px" }}>Showing {this.state.total_cars} Cars</span>
                                            </div>

                                        </div>
                                        {paginationData}
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-md-12 loader">
                                        <div className="spinner-border text-dark mb-3 ml-3" role="status">
                                            <span className="sr-only">Loading...</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="section-padding partners hwefeature pt-5 pb-0">
                    <Cars />
                    <Media />
                    <FAQ />
                    <Details />
                </section>
            </Fragment>

        );
    }
}

export default Content;