import React from 'react';
import { Link } from 'react-router-dom';
import NavHelper from '../../helper/NavHelper';
import Topnavigation from '../../data/Topnavigation.json';
import "./layoutstyle.css";
import $ from "jquery";
import * as CONSTANT from '../../Constent';

class Header extends NavHelper {
    constructor(props) {
        super(props);
        this.state = {
            city_id: "",
            city: [],
            make: [],
            model: [],
            fueltype: [],
            year: [],
        };
        this.handleClick = this.handleClick.bind(this);
        this.handleclick1 = this.handleclick1.bind(this);
        this.handleKeyUp = this.handleKeyUp.bind(this);
    }

    componentDidMount() {

        const city_id = localStorage.getItem("city_id");
        this.setState({ city_id: city_id })

        ///////////////////Get City////////////////////
        fetch(`${CONSTANT.BaseUrl}/services/getcity`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ city: response.result })
            })
            .catch((error) => {
            });

        ///////////////////Get Make////////////////////
        fetch(`${CONSTANT.BaseUrl}/services/getmake`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ make: response.result })
                $(".loader").hide();
            })
            .catch((error) => {
            });

        ///////////////////Get Modal////////////////////
        fetch(`${CONSTANT.BaseUrl}/services/getmodel`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ model: response.result })
                $(".loader1").hide();
            })
            .catch((error) => {
            });

        ///////////////////Get Fueltype////////////////////
        fetch(`${CONSTANT.BaseUrl}/services/getfueltype`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ fueltype: response.result })
                $(".loader2").hide();
            })
            .catch((error) => {
            });

        ///////////////////Get Year////////////////////
        fetch(`${CONSTANT.BaseUrl}/services/getyear`, {
            method: 'GET',
        })
            .then((response) => response.json())
            .then((response) => {
                this.setState({ year: response.result })
                $(".loader3").hide();
            })
            .catch((error) => {
            });
    }

    handleClick(min, max) {
        window.location.replace('/category?city_ids=' + this.state.city_id + '&car_min_price=' + min + '&car_max_price=' + max);
    }

    handleclick1(e) {
        if (window.matchMedia('(max-width: 992px)').matches) {
            $(".menu-item" + e).children(".submenu").toggle();
        }
    }

    handleKeyUp = event => {
        $(".data_list").html('');

        $(".data_list").text("Loading...");
        setTimeout(function () {
            var search = event.target.value;
            if (search != "") {
                $.ajax({
                    url: `${CONSTANT.BaseUrl}/services/getseach_val?searchval=${search}`,
                    type: 'GET',
                    dataType: 'json',
                    success: function (response) {
                        $(".data_list").hide();
                        var status = response.status;
                        var len = response.result.length;
                        if (status == 0) {
                            $(".data_list").text("");
                            $(".data_list").html('');
                            $(".data_list").append("<li style='width: 100%; text-decoration: none; font-size: 15px; color: grey;'>Result not found &nbsp; <i class='fa fa-search'></i> </li>");
                        }
                        else if (status == 1) {
                            $(".data_list").text("");
                            for (var i = 0; i < len; i++) {
                                var makelength = response.result[i].make.length;
                                for (var j = 0; j < makelength; j++) {
                                    var index = response.result[i].make[j]['index'];
                                    var name = response.result[i].make[j]['name'];
                                    var type = response.result[i].make[j]['type'];
                                    if (type == "make") {
                                        $(".data_list").append("<div class='search_val' style='display: flex; justify-content: space-between;'><li style='font-weight: 600;' value='" + index + "' checktype='" + type + "'>" + name + "</li><i class='fa fa-arrow-right' style='position: relative; top: 10px; color: #2e054e;'></i></div>");
                                    }
                                    else if (type == "modal") {
                                        $(".data_list").append("<div class='search_val' style='display: flex; justify-content: space-between;'><li style='padding-left: 15px;' value='" + index + "' checktype='" + type + "'>" + name + "</li><i class='fa fa-arrow-right' style='position: relative; top: 10px; color: #2e054e;'></i></div>");
                                    }
                                }
                            }
                        }
                        setTimeout(function () {
                            $(".data_list").show();
                        }, 1000);
                    }
                })
            }
            else {
                $(".data_list").hide();
            }
        }, 2000);
    }

    render() {
        if (window.matchMedia('(max-width: 992px)').matches) {
            $(".mainnavhwe").css({ "height": "1500px", "overflow": "scroll" });
            $(".bycararrow").parent().hide();
        }

        const city_id = localStorage.getItem("city_id");
        const selected_city = localStorage.getItem("selected_city");
        if (selected_city) {
            $("#select_city_id").val(city_id);
            $(".select_city").html(selected_city + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + '<i class="fa fa-caret-down"></i>');
        }
        else {
            $("#select_city_id").val("");
            $(".select_city").html("Select city" + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + '<i class="fa fa-caret-down"></i>');
        }


        $(document).ready(function () {
            $(".top_city").click(function () {
                var cityid = $(this).attr('data-id');
                var dataname = $(this).html();

                localStorage.setItem('city_id', cityid);
                localStorage.setItem('selected_city', dataname);
                window.location.replace(`/category?city_ids=` + cityid);
            });
        });

        $(document).ready(function () {

            $(".select_city").click(function () {
                $("#exampleModal").show();
            });

            $(".close").click(function () {
                $("#exampleModal").fadeOut();
            });

            $(".body_content").click(function () {
                var city_id = $(this).find('input').val();
                var selected_city = $(this).find('h6').html();
                $("#select_city_id").val(city_id);
                $(".select_city").html(selected_city + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + '<i class="fa fa-caret-down"></i>');
                localStorage.setItem('city_id', city_id);
                localStorage.setItem('selected_city', selected_city);
                $("#exampleModal").hide();
                window.location.replace("/");
            });

            $(document).on("click", ".search_val", function () {
                var search_val = $(this).find('li').val();
                var final_select = $(this).find('li').html();
                var checktype = $(this).find('li').attr("checktype");

                if (checktype == "make") {
                    $("#make_ids").val(search_val);
                }
                else if (checktype == "modal") {
                    $("#modal_ids").val(search_val);
                }

                $("#final_select").val(final_select);
                $(".data_list").hide();

                $(".search_action").trigger("click");
            });

        });

        // $(document).ready(function () {

        // $(".search_data").keyup(function () {
        //     $(".data_list").css("display", "none");
        //     $(".data_list").html('');

        //     var search = $(this).val();
        //     $(".data_list").text("Loading...");

        //     if (search != "") {
        //         $.ajax({
        //             url: `${CONSTANT.BaseUrl}/services/getseach_val`,
        //             type: 'GET',
        //             data: { searchval: search },
        //             dataType: 'json',
        //             success: function (response) {
        //                 setTimeout(function() {
        //                     var status = response.status;
        //                     var len = response.result.length;
        //                     if (status == 0) {
        //                         $(".data_list").text("");
        //                         $(".data_list").html('');
        //                         $(".data_list").append("<li style='width: 100%; text-decoration: none; font-size: 15px; color: grey;'>Result not found &nbsp; <i class='fa fa-search'></i> </li>");
        //                     }
        //                     else if (status == 1) {
        //                         $(".data_list").text("");
        //                         for (var i = 0; i < len; i++) {
        //                             var makelength = response.result[i].make.length;
        //                             for (var j = 0; j < makelength; j++) {
        //                                 var index = response.result[i].make[j]['index'];
        //                                 var name = response.result[i].make[j]['name'];
        //                                 var type = response.result[i].make[j]['type'];

        //                                 if (type == "make") {
        //                                     $(".data_list").append("<div class='search_val' style='display: flex; justify-content: space-between;'><li style='font-weight: 600;' value='" + index + "' checktype='" + type + "'>" + name + "</li><i class='fa fa-arrow-right' style='position: relative; top: 10px; color: #2e054e;'></i></div>");
        //                                 }
        //                                 if (type == "modal") {
        //                                     $(".data_list").append("<div class='search_val' style='display: flex; justify-content: space-between;'><li style='padding-left: 15px;' value='" + index + "' checktype='" + type + "'>" + name + "</li><i class='fa fa-arrow-right' style='position: relative; top: 10px; color: #2e054e;'></i></div>");
        //                                 }
        //                             }
        //                         }
        //                     }
        //                 }, 2000);
        //             }
        //         })
        //         $(".data_list").show();
        //     }
        //     else {
        //         $(".data_list").hide();
        //     }
        // });
        // });

        const stickyHeader = this.state.stickyHeader ? 'sticky' : '';
        return (
            <header className="header">

                <div className="topbar bg-theme" style={{ padding: "1rem 2rem", backgroundColor: "#fff", borderBottom: "1px solid #dbdbdb" }}>
                    <div className="container-fluid topheader_bar">
                        <div className="row">
                            <div className="col-md-8">
                                <div className="leftside">
                                    <div className="row">
                                        <div className="col-md-3 mt-1">
                                            <div className="logo"> <Link to="/"> <img src={process.env.PUBLIC_URL + "/assets/images/logo5.png"} className="img-fluid" alt="logo" style={{ width: "100%", height: "35px" }} /> </Link> </div>
                                        </div>
                                        <div className="col-md-9">
                                            <form method="GET" action="/category">
                                                <div className="row">
                                                    <div className="col-md-4">
                                                        <input type="hidden" name="city_ids" id="select_city_id" Value="" />
                                                        <button type="button" className="btn btn-block select_city">Select city &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <i className="fa fa-caret-down"></i></button>
                                                    </div>
                                                    <div className="col-md-8 searchhwe" style={{ paddingLeft: "0px" }}>
                                                        <div className="form_data_search">
                                                            <input type="hidden" name="make_ids[]" id="make_ids" Value="" />
                                                            <input type="hidden" name="modal_ids[]" id="modal_ids" Value="" />

                                                            <input type="search" onChange={this.handleKeyUp} placeholder="Search by Make & Modal etc." id="final_select" className="search_data" autoComplete='off' />
                                                            <button type="submit" className="search_action" >Search</button>
                                                        </div>

                                                        <div className="data_list" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none" }}>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-4 topmenuhwe">
                                <ul className="custom-flex" style={{ justifyContent: "space-evenly", position: "relative", top: "20%", zIndex: "10" }}>
                                    {Topnavigation.length > 0 ? Topnavigation.map((item, i) => (
                                        <li key={i} className={`menu-item ${item.child ? 'menu-item-has-children' : ''} `} onClick={this.triggerChild} style={{ fontFamily: "Futura Hv BT", fontWeight: "500" }}>
                                            {item.child ? <Link style={{ color: "#2e054e", fontWeight: "500", fontSize: "15px" }} onClick={e => e.preventDefault()} to="/" > {item.linkText} <span className="arrow bycararrow" /></Link> : <Link style={{ color: "#2e054e", fontWeight: "500", fontSize: "15px" }} to={item.link} className="text-theme fs-14"> {item.linkText} </Link>}
                                            {item.child ?
                                                <ul className="custom submenu top_right_submenu" role="menu" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none", width: "350px", padding: "10px" }}>
                                                    <div className="row">
                                                        <div className="col-md-5">
                                                            {this.state.city.map(city =>
                                                                <li className={`menu-item custome_menu_item mb-3`}>
                                                                    <Link to={""} className="text-theme custome_menu top_city" data-id={city.id} > {city.city} </Link>
                                                                </li>
                                                            )}
                                                            <li className={`menu-item custome_menu_item mb-3`}>
                                                                <Link to={""} className="text-theme custome_menu top_city" data-id="all" > All India </Link>
                                                            </li>
                                                        </div>
                                                        <div className="col-md-7">
                                                            <li className={`menu-item custome_menu_item mb-3`} onClick={() => this.handleClick(100000, 300000)}>
                                                                <Link to={''} className="text-theme custome_menu"> 1 - 3L </Link>
                                                            </li>
                                                            <li className={`menu-item custome_menu_item mb-3`} onClick={() => this.handleClick(300000, 600000)}>
                                                                <Link to={''} className="text-theme custome_menu"> 3L - 6L </Link>
                                                            </li>
                                                            <li className={`menu-item custome_menu_item mb-3`} onClick={() => this.handleClick(600000, 1000000)}>
                                                                <Link to={''} className="text-theme custome_menu"> 6L - 10L </Link>
                                                            </li>
                                                            <li className={`menu-item custome_menu_item mb-3`} onClick={() => this.handleClick(1000000, 1500000)}>
                                                                <Link to={''} className="text-theme custome_menu"> 10L - 15L </Link>
                                                            </li>
                                                            <li className={`menu-item custome_menu_item mb-3`} onClick={() => this.handleClick(1500000, 2000000)}>
                                                                <Link to={''} className="text-theme custome_menu"> 15L - 20L </Link>
                                                            </li>
                                                            <li className={`menu-item custome_menu_item mb-3`} onClick={() => this.handleClick(2000000, 4000000)}>
                                                                <Link to={''} className="text-theme custome_menu"> 20L & Above </Link>
                                                            </li>
                                                        </div>
                                                    </div>
                                                </ul>
                                                : null
                                            }
                                        </li>
                                    )) : null}
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div className={"navigation-wrapper" + stickyHeader}>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-12">
                                <nav>
                                    <div className="main-navigation">
                                        <div className={this.state.navMethod === true ? 'main-menu active' : 'main-menu'}>
                                            <ul className="custom-flex mainnavhwe" style={{ justifyContent: "flex-start" }}>
                                                &nbsp;&nbsp;
                                                <li className={`menu-item`}>
                                                    <Link style={{ color: "grey", fontFamily: "Futura Lt BT" }} to="/" className="text-theme fs-14"> Explore By </Link>
                                                </li>
                                                <li className={`menu-item menu-item-has-children menu-item1`} onClick={() => this.handleclick1(1)}>
                                                    <Link style={{ color: "#2e054e", fontFamily: "Futura Lt BT" }} to="/"> Price <span className="arrow" /></Link>
                                                    <ul className="custom submenu" role="menu" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none", padding: "20px" }}>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&car_min_price=100000&car_max_price=300000`} className="text-theme"> 1 - 3L </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&car_min_price=300000&car_max_price=600000`} className="text-theme"> 3L - 6L </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&car_min_price=600000&car_max_price=1000000`} className="text-theme"> 6L - 10L </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&car_min_price=1000000&car_max_price=1500000`} className="text-theme"> 10L - 15L </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&car_min_price=1500000&car_max_price=2000000`} className="text-theme"> 15L - 20L </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&car_min_price=2000000&car_max_price=4000000`} className="text-theme"> 20L & Above </Link>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li className={`menu-item menu-item-has-children menu-item2`} onClick={() => this.handleclick1(2)}>
                                                    <Link style={{ color: "#2e054e", fontFamily: "Futura Lt BT" }} to="/"> Make <span className="arrow" /></Link>
                                                    <ul className="custom submenu" role="menu" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none", padding: "20px" }}>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <div className="spinner-border text-dark mb-3 ml-3 loader" role="status">
                                                                <span className="sr-only">Loading...</span>
                                                            </div>
                                                        </li>
                                                        {this.state.make.map(make =>
                                                            <li className={`menu-item menu-item-has-children`}>
                                                                <Link to={`/category?city_id=${this.state.city_id}&make_ids[]=${make.index}`} className="text-theme"> {make.name} </Link>
                                                            </li>
                                                        )}
                                                    </ul>
                                                </li>
                                                <li className={`menu-item menu-item-has-children menu-item3`} onClick={() => this.handleclick1(3)}>
                                                    <Link style={{ color: "#2e054e", fontFamily: "Futura Lt BT" }} to="/"> Model <span className="arrow" /></Link>
                                                    <ul className="custom submenu" role="menu" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none", padding: "20px" }}>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <div className="spinner-border text-dark mb-3 ml-3 loader1" role="status">
                                                                <span className="sr-only">Loading...</span>
                                                            </div>
                                                        </li>
                                                        {this.state.model.map(model =>
                                                            <li className={`menu-item menu-item-has-children`}>
                                                                <Link to={`/category?city_id=${this.state.city_id}&modal_ids[]=${model.index}`} className="text-theme"> {model.name} </Link>
                                                            </li>
                                                        )}
                                                    </ul>
                                                </li>
                                                <li className={`menu-item menu-item-has-children menu-item4`} onClick={() => this.handleclick1(4)}>
                                                    <Link style={{ color: "#2e054e", fontFamily: "Futura Lt BT" }} to="/"> Fuel Type <span className="arrow" /></Link>
                                                    <ul className="custom submenu" role="menu" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none", padding: "20px" }}>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <div className="spinner-border text-dark mb-3 ml-3 loader2" role="status">
                                                                <span className="sr-only">Loading...</span>
                                                            </div>
                                                        </li>
                                                        {this.state.fueltype.map(fueltype =>
                                                            <li className={`menu-item menu-item-has-children`}>
                                                                <Link to={`/category?city_id=${this.state.city_id}&fuel_type[]=${fueltype.index}`} className="text-theme"> {fueltype.name} </Link>
                                                            </li>
                                                        )}
                                                    </ul>
                                                </li>
                                                <li className={`menu-item menu-item-has-children menu-item5`} onClick={() => this.handleclick1(5)}>
                                                    <Link style={{ color: "#2e054e", fontFamily: "Futura Lt BT" }} to="/"> Year <span className="arrow" /></Link>
                                                    <ul className="custom submenu" role="menu" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none", padding: "20px" }}>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <div className="spinner-border text-dark mb-3 ml-3 loader3" role="status">
                                                                <span className="sr-only">Loading...</span>
                                                            </div>
                                                        </li>
                                                        {this.state.year.map(year =>
                                                            <li className={`menu-item menu-item-has-children`}>
                                                                <Link to={`/category?city_id=${this.state.city_id}&car_year=${year.name}`} className="text-theme"> {year.name} & Above</Link>
                                                            </li>
                                                        )}
                                                    </ul>
                                                </li>
                                                <li className={`menu-item menu-item-has-children menu-item6`} onClick={() => this.handleclick1(6)}>
                                                    <Link style={{ color: "#2e054e", fontFamily: "Futura Lt BT" }} to="/"> KM Driven <span className="arrow" /></Link>
                                                    <ul className="custom submenu" role="menu" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none", padding: "20px" }}>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&km_driven=10000`} className="text-theme"> {new Intl.NumberFormat('US').format(10000)} kms & less </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&km_driven=30000`} className="text-theme"> {new Intl.NumberFormat('US').format(30000)} kms & less </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&km_driven=50000`} className="text-theme"> {new Intl.NumberFormat('US').format(50000)} kms & less </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&km_driven=75000`} className="text-theme"> {new Intl.NumberFormat('US').format(75000)} kms & less </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&km_driven=100000`} className="text-theme"> {new Intl.NumberFormat('US').format(100000)} kms & less </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&km_driven=200000`} className="text-theme"> {new Intl.NumberFormat('US').format(200000)} kms & less </Link>
                                                        </li>
                                                    </ul>
                                                </li>
                                                <li className={`menu-item menu-item-has-children menu-item7`} onClick={() => this.handleclick1(7)}>
                                                    <Link style={{ color: "#2e054e", fontFamily: "Futura Lt BT" }} to="/"> Owner <span className="arrow" /></Link>
                                                    <ul className="custom submenu" role="menu" style={{ maxHeight: "300px", overflowY: "scroll", scrollbarWidth: "none", padding: "20px" }}>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&owner=1`} className="text-theme"> 1-owner </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&owner=2`} className="text-theme"> 2-owner </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&owner=3`} className="text-theme"> 3-owner </Link>
                                                        </li>
                                                        <li className={`menu-item menu-item-has-children`}>
                                                            <Link to={`/category?city_id=${this.state.city_id}&owner=4`} className="text-theme"> 4 or more-owner </Link>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="hamburger-menu" onClick={this.toggleNav}>
                                            <div className={this.state.navMethod === true ? 'menu-btn active' : 'menu-btn'}> <span /> <span /> <span /> </div>
                                        </div>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="exampleModal">
                    <div className="modal-dialog custome_dialog">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h5 className="modal-title" id="exampleModalLabel">Select a city</h5>
                                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>

                            <div className="modal-body" style={{ padding: "1rem 2rem" }}>
                                <div className="row">
                                    {this.state.city.map(city =>
                                        <div className="col-md-2 text-center body_content">
                                            <input type="hidden" Value={city.id} />
                                            <img src={process.env.PUBLIC_URL + "/assets/images/city/city.png"} className="img-fluid" alt="logo" />
                                            <h6>{city.city}</h6>
                                        </div>
                                    )}
                                    <div className="col-md-2 text-center body_content">
                                        <input type="hidden" Value="all" />
                                        <img src={process.env.PUBLIC_URL + "/assets/images/city/city.png"} className="img-fluid" alt="logo" />
                                        <h6>All India</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        );
    }
}

export default Header;